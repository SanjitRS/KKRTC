@echo off
title Epic of Conquest: 3D Interactive Mahabharata Saga
cd /d "%~dp0"
echo ======================================================
echo   Launching Epic of Conquest: Mahabharata Saga...
echo ======================================================
start "" "%~dp0EpicOfConquest.exe"
exit
