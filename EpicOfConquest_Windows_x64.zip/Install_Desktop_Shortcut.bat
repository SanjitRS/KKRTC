@echo off
title Install Epic of Conquest Shortcut
cd /d "%~dp0"

echo Creating desktop shortcut for Epic of Conquest...

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Epic of Conquest.lnk'); $s.TargetPath = '%~dp0EpicOfConquest.exe'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'Epic of Conquest: 3D Interactive Mahabharata Saga'; $s.Save()"

echo.
echo ========================================================
echo   SUCCESS! Desktop shortcut created:
echo   'Epic of Conquest' is now on your Desktop!
echo ========================================================
echo.
pause
