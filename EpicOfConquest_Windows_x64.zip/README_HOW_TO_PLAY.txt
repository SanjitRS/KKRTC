========================================================================
   EPIC OF CONQUEST: 3D INTERACTIVE MAHABHARATA SAGA
   Windows Standalone Release (Ready to Play on Any Laptop)
========================================================================

HOW TO INSTALL & PLAY:
----------------------
1. Double-click "EpicOfConquest.exe" (or "Play_Game.bat") to launch the game!
2. (Optional) Run "Install_Desktop_Shortcut.bat" to put a 1-click icon on your Desktop.
3. No installation or extra software required — runs completely offline on Windows 10 & 11!

KEYBOARD CONTROLS & SHORTCUTS:
-----------------------------
- F11: Toggle Fullscreen Mode
- H: Open "Krishna's Counsel" (Hints)
- M: Toggle Sanjay's spoken narration voice (ON / OFF)
- Mouse Click: Select story choices, target archery, sparring combos

THE 9 CHRONOLOGICAL STAGES:
---------------------------
Stage 1: Ved Vyas & Ganesha (Prologue puzzle & metrical assembly)
Stage 2: Pandava Gurukul (Eye of the bird archery, sparring & Eklavya's choice)
Stage 3: Barbarik & Krishna (Three infallible arrows & head sacrifice)
Stage 4: Vishnu Vishwaroop (Cosmic perception, Gita sermon & Gandiva awaken)
Stage 5: Bhishma's Bed of Arrows (Wave defense, Shikhandi approach & willed yield)
Stage 6: Abhimanyu's Chakravyuha (Rotating multi-ring maze with NO EXIT)
Stage 7: Ghatotkacha's Death (Nocturnal Maya Astra & Vasavi Shakti sacrifice)
Stage 8: Karna's Last Stand (Mantra forgetting curse & wheel stuck in mud)
Stage 9: Ashwathama's Vow (Brahmashirastra invocation & cumulative Vidya withdrawal check)

CORE MECHANIC: VIDYA GATES ASTRA
--------------------------------
- Astra Tier is gated by cumulative Vidya (knowledge/dharma clarity), NEVER by grinding or currency!
- Tier 1: 0 Vidya (Earthly Bow, Mace, Sword)
- Tier 2: 100 Vidya (Gandiva Bow of Arjuna, Vijaya of Karna)
- Tier 3: 300 Vidya (Celestial Astras: Agneyastra, Varunastra, Sudarshana Chakra)
- Tier 4: 600 Vidya (Brahmastra, Brahmashirastra)

FINALE BRANCHING:
-----------------
Stage 9 tests your cumulative Vidya from all 8 previous stages!
- Vidya >= 550: "The Repentant" Ending (Weapon recalled, soul saved)
- Vidya < 550: "Cursed Immortal" Ending (3,000-year wandering curse)

Save data is automatically saved locally on your laptop. Enjoy the saga!
========================================================================
